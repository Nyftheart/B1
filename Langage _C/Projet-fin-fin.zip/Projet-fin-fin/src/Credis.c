#include "rogue.h"
#include "main.h"


void Credis()
{
    
    int ch = 'e';
    
    /* main game loop */

        if (ch != 'e')
        {
            menuLoop();
        }
        printw("Credis\n");
        printw("alex\n");
        printw("yann\n");

        ch = getch();
        
    

}