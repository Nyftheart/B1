#ifndef POSITION_H
#define POSITION_H


typedef struct Position {
    int x;
    int y;
    // TILE_TYPE tile;
} Position;


#endif