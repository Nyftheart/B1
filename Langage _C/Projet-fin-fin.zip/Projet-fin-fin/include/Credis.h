#ifndef CREDIS_H
#define CREDIS_H


void Credis();

#endif